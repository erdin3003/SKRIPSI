<?php
    error_reporting(0);

    function dateToWeek($qDate){
        $dt = strtotime($qDate);
        $day  = date('j',$dt);
        $month = date('m',$dt);
        $year = date('Y',$dt);
        $totalDays = date('t',$dt);
        $weekCnt = 1;
        $retWeek = 0;
        for($i=1;$i<=$totalDays;$i++) {
            $curDay = date("N", mktime(0,0,0,$month,$i,$year));
            if($curDay==7) {
                if($i==$day) {
                    $retWeek = $weekCnt+1;
                }
                $weekCnt++;
            } else {
                if($i==$day) {
                    $retWeek = $weekCnt;
                }
            }
        }
        return $retWeek;
    }

    date_default_timezone_set("Asia/Jakarta");
    $menu="rekap";
    $bln = date('m');
    $thn = date('Y');
    $min = dateToWeek(date('Y-m-d'));

    mysqli_query($konek, "DELETE FROM tmprekap");
?>

<!DOCTYPE html>
<html>
<head>
	<?php include "header.php"; ?>
	<title>Absensi RFID</title>

    <script type="text/javascript">
        function bacarekap()
        {
            var bulan = document.getElementById('bulan').value;
            var tahun = document.getElementById('tahun').value;
            var minggu = document.getElementById('minggu').value;
            var nama = document.getElementById('keyword').value;

            var xmlhttp=new XMLHttpRequest();
            xmlhttp.onreadystatechange=function() {
              if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                document.getElementById("data-absen").innerHTML=xmlhttp.responseText;
              }
            }
            xmlhttp.open("GET","bacarekap.php?bulan=" + bulan + "&tahun=" + tahun + "&minggu=" + minggu + "&nama=" + nama,true);
            xmlhttp.send();   
            tampilpekerja();
        }

        function tampilrekap(bulan, tahun, minggu, nama)
        {
            var xmlhttp=new XMLHttpRequest();
            xmlhttp.onreadystatechange=function() {
              if (xmlhttp.readyState==4 && xmlhttp.status==200) {
                document.getElementById("data-absen").innerHTML=xmlhttp.responseText;
              }
            }
            xmlhttp.open("GET","bacarekap.php?bulan=" + bulan + "&tahun=" + tahun + "&minggu=" + minggu + "&nama=" + nama,true);
            xmlhttp.send();   
        }

    </script>
</head>
<body onload="tampilrekap('<?php echo $bln; ?>', '<?php echo $thn; ?>', '<?php echo $min; ?>', '')">
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div style="display: flex; justify-content: space-between;">
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
						<a href="admin.php"> <button class="btn btn-primary" style="color: white; margin-right: 1px">SMKN7BE</button></a>
						<a href="admin.php"> <button class="btn btn-default" style="margin-right: 1px">Home</button></a>
						</div>
					</li>
				</ul>
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
							<a href="logout.php"> <button class="btn btn-default" style="margin-right: 1px">Logout</button></a>
						</div>
					</li>
				</ul>				
			</div>
		</div>
	</nav>

	<!-- isi -->
	<div class="container-fluid" style="padding-top: 2%">
		  <div class="row" style="margin-left: 10px">
		    <div class="col-6 col-sm-3">
		    	<?php include "menu.php"; ?>
		    </div> 
		    <div class="col-6 col-sm-9" style="text-align: center;">
		    	<!--isi -->
                <div class="container-fluid">
                    <h3 style="text-align: left">Rekap Absensi</h3>
                    <div style="display: flex; justify-content: space-between;">
                        <div style="display: flex">
                            <select class="form-control form-control-sm" id="bulan" name="bulan" onchange="bacarekap()">
                                <option value="1" <?php if($bln=="1") echo "selected"; ?>>Januari</option>
                                <option value="2" <?php if($bln=="2") echo "selected"; ?>>Februari</option>
                                <option value="3" <?php if($bln=="3") echo "selected"; ?>>Maret</option>
                                <option value="4" <?php if($bln=="4") echo "selected"; ?>>April</option>
                                <option value="5" <?php if($bln=="5") echo "selected"; ?>>Mei</option>
                                <option value="6" <?php if($bln=="6") echo "selected"; ?>>Juni</option>
                                <option value="7" <?php if($bln=="7") echo "selected"; ?>>Juli</option>
                                <option value="8" <?php if($bln=="8") echo "selected"; ?>>Agustus</option>
                                <option value="9" <?php if($bln=="9") echo "selected"; ?>>September</option>
                                <option value="10" <?php if($bln=="10") echo "selected"; ?>>Oktober</option>
                                <option value="11" <?php if($bln=="11") echo "selected"; ?>>Nopember</option>
                                <option value="12" <?php if($bln=="12") echo "selected"; ?>>Desember</option>
                            </select>&nbsp;
                            <input style="width: 70px" type="text" name="tahun" id="tahun" class="form-control form-control-sm" placeholder="tahun" value="<?php echo  $thn; ?>" onkeyup="bacarekap()">&nbsp;
                            <select class="form-control form-control-sm" id="minggu" name="minggu" onchange="bacarekap()">
                                <option value="1" <?php if($min=="1") echo "selected"; ?>>Minggu Pertama</option>
                                <option value="2" <?php if($min=="2") echo "selected"; ?>>Minggu Kedua</option>
                                <option value="3" <?php if($min=="3") echo "selected"; ?>>Minggu Ketiga</option>
                                <option value="4" <?php if($min=="4") echo "selected"; ?>>Minggu Keempat</option>
                                <option value="5" <?php if($min=="5") echo "selected"; ?>>Minggu Kelima</option>
                            </select>&nbsp;
                            <a href="export.php" target="_blank" style="text-decoration: none"><button class="btn btn-primary">Export</button></a>&nbsp;
                            <a href="cetak.php" target="_blank" style="text-decoration: none"><button class="btn btn-warning">Cetak</button></a>
                        </div>
                        <div>
                            <input type="text" name="keyword" id="keyword" class="form-control form-control-sm" placeholder="pencarian nama" onkeyup="bacarekap()">
                        </div>
                    </div><br>
                    <span id="data-absen"></span>
                </div>
		    </div>
		  </div>
	</div>
</body>
</html>