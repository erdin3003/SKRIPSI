<div class="footer" style="text-align: center">
	Ramot Hamonangan Sitompul
</div>