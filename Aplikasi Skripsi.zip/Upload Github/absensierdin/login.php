<!DOCTYPE html>
<html>
<head>
	<?php 
		include "header.php";
		include "jsScript.php";
		session_start();
	?>

	<title>Absensi RFID</title>
</head>
<body>
	<?php
		include "koneksi.php";
		if(isset($_POST['btnLogin']))
		{
			$username = mysqli_real_escape_string($konek,$_POST['username']);
			$password = md5(mysqli_real_escape_string($konek,$_POST['password']));
        	$sql = mysqli_query($konek, "SELECT * FROM user WHERE username='$username' AND password='$password'");
        	if(mysqli_num_rows($sql))
        	{
        		$data = mysqli_fetch_array($sql);
          		$_SESSION["usr"] = "adminx";
        		echo "<script>pesan('Sukses', 'Selamat Datang', 'success', 'admin.php');</script>";
        	}
        	else
        	{
        		echo "<script>pesan('Error', 'Gagal Login', 'error', 'login.php');</script>";	
        	}
		}
	?>
	<!-- isi -->
	<div class="container-fluid" style="padding-top: 10%; text-align: center">
		<h1 style="font-weight: bold">LOGIN</h1>
		<div class=" container card" style="width: 40rem; border-style: solid; border-radius: 10px; padding: 20px">
		  <div class="card-body">
		  	<form method="POST">
			  	<div style="text-align: left">
			    	<lable style="font-weight: bold">Username</lable><br>
			    	<input type="text" name="username" class="form-control form-control-sm" placeholder="username">
			    </div>
			    <div style="margin-top: 10px; text-align: left">
			    	<lable style="font-weight: bold">Password</lable><br>
			    	<input type="password" name="password" class="form-control form-control-sm" placeholder="username">
			    </div>
			    <div style="margin-top: 10px; text-align: center;">
			    	<button type="submit" class="btn btn-primary" name="btnLogin" id="btnLogin">Login</button>
			    </div>
			    <div style="margin-top: 20px; text-align: center;">
			    	<a href="index.php">Absensi</a>
				</div>
			</form>
		  </div>
		</div>
	</div>
</body>
</html>