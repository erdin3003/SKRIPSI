<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php include "jsScript.php"; ?>
</head>
<body>
<?php
	error_reporting(0);
	include "koneksi.php";

	//baca id data yang akan dihapus
	$id = $_GET['id'];

	//hapus data
	$hapus = mysqli_query($konek, "delete from karyawan where id='$id'");

	//jika berhasil terhapus tampilkan pesan Terhapus
	//kemudian kembali ke data karyawan
	if($hapus)
	{
		echo "
			<script>
				pesan('Sukses', 'Berhasil dihapus', 'success', 'datakaryawan.php');
			</script>
		";
	}
	else
	{
		echo "
			<script>
				pesan('Error', 'Gagal dihapus', 'error', 'datakaryawan.php');
			</script>
		";
	}

?>
</body>
</html>