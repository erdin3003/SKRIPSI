<div class="card" style="width: 30rem;">
  <div class="card-header">
    <h4>Menu Utama</h4>
  </div>
  <ul class="list-group list-group-flush">
    <a href="admin.php" style="text-decoration: none"><li class="list-group-item <?php if($menu=="admin") echo "active"; ?>">Dashboard</li></a>
    <a href="datakaryawan.php" style="text-decoration: none"><li class="list-group-item <?php if($menu=="datakaryawan") echo "active"; ?>">Data Karyawan</li></a>
    <a href="rekap.php" style="text-decoration: none"><li class="list-group-item <?php if($menu=="rekap") echo "active"; ?>">Rekap Absensi</li></a>
  </ul>
</div>