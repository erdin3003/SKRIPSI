<!DOCTYPE html>
<html>
<head>
	<?php 
		error_reporting(0);
		include "header.php";
		session_start();
		$menu="admin";
		$user="";
		$user = $_SESSION["usr"];
		if($user == "adminx"){}
		else {	
			echo "<script>location.replace('index.php');</script>";
		}
	?>

	<title>Absensi RFID</title>
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div style="display: flex; justify-content: space-between;">
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
						<a href="admin.php"> <button class="btn btn-primary" style="color: white; margin-right: 1px">SMKN7BE</button></a>
						<a href="admin.php"> <button class="btn btn-default" style="margin-right: 1px">Home</button></a>
						</div>
					</li>
				</ul>
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
							<a href="logout.php"> <button class="btn btn-default" style="margin-right: 1px">Logout</button></a>
						</div>
					</li>
				</ul>				
			</div>
		</div>
	</nav>

	<!-- isi -->
	<div class="container-fluid" style="padding-top: 2%">
		  <div class="row" style="margin-left: 10px">
		    <div class="col-6 col-sm-3">
		    	<?php include "menu.php"; ?>
		    </div> 
		    <div class="col-6 col-sm-9" style="text-align: center; padding-top: 100px">
		    	<h1>
					<b>SELAMAT DATANG ADMIN</b> <br>
					<span style="font-size: 24px">APLIKASI ABSENSI RFID SMK NEGERI 7 BALEENDAH</span>
				</h1>
		    </div>
		  </div>
	</div>
</body>
</html>