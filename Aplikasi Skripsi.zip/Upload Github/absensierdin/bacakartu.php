<?php 
	include "koneksi.php";


    function dateToWeek($qDate){
	    $dt = strtotime($qDate);
	    $day  = date('j',$dt);
	    $month = date('m',$dt);
	    $year = date('Y',$dt);
	    $totalDays = date('t',$dt);
	    $weekCnt = 1;
	    $retWeek = 0;
	    for($i=1;$i<=$totalDays;$i++) {
	        $curDay = date("N", mktime(0,0,0,$month,$i,$year));
	        if($curDay==7) {
	            if($i==$day) {
	                $retWeek = $weekCnt+1;
	            }
	            $weekCnt++;
	        } else {
	            if($i==$day) {
	                $retWeek = $weekCnt;
	            }
	        }
	    }
	    return $retWeek;
    }

    function hari_ini(){
		$hari = date ("D");
		switch($hari){
			case 'Sun':
				$hari_ini = "Minggu";
			break;
			case 'Mon':			
				$hari_ini = "Senin";
			break;
			case 'Tue':
				$hari_ini = "Selasa";
			break;
			case 'Wed':
				$hari_ini = "Rabu";
			break;
			case 'Thu':
				$hari_ini = "Kamis";
			break;
			case 'Fri':
				$hari_ini = "Jumat";
			break;
			case 'Sat':
				$hari_ini = "Sabtu";
			break;
			default:
				$hari_ini = "Tidak di ketahui";		
			break;
		}
		return $hari_ini;
	}

    date_default_timezone_set("Asia/Jakarta");
    $min = dateToWeek(date('Y-m-d'));
    $hari = hari_ini();

	//baca tabel status untuk mode absensi
	$sql = mysqli_query($konek, "select * from status");
	$data = mysqli_fetch_array($sql);
	$mode_absen = $data['mode'];		

	//uji mode absen
	$mode = "";
	if($mode_absen==1)
		$mode = "Masuk";
	else if($mode_absen==2)
		$mode = "Pulang";


	//baca tabel tmprfid
	$baca_kartu = mysqli_query($konek, "select * from tmprfid");
	$nokartu = "";
	if(mysqli_num_rows($baca_kartu) > 0)
	{
		$data_kartu = mysqli_fetch_array($baca_kartu);
		$nokartu    = $data_kartu['nokartu'];
	}
?>


<div class="container-fluid" style="text-align: center;">
	<?php if($nokartu=="") { ?>

	<h3>Absen : <?php echo $mode; ?> </h3>
	<img src="images/rfid.png" style="width: 200px"> <br>
	<img src="images/animasi2.gif">

	<?php } else {
		if($hari!="Minggu")
		{
			//cek nomor kartu RFID tersebut apakah terdaftar di tabel karyawan
			$cari_karyawan = mysqli_query($konek, "select * from karyawan where nokartu='$nokartu'");
			$jumlah_data = mysqli_num_rows($cari_karyawan);

			if($jumlah_data==0)
				echo "<h1>Maaf! Kartu Tidak Dikenali</h1>";
			else
			{
				//ambil nama karyawan
				$data_karyawan = mysqli_fetch_array($cari_karyawan);
				$nama = $data_karyawan['nama'];

				//tanggal dan jam hari ini
				date_default_timezone_set('Asia/Jakarta') ;
				$tanggal = date('Y-m-d');
				$jam     = date('H:i:s');

				//cek di tabel absensi, apakah nomor kartu tersebut sudah ada sesuai tanggal saat ini. Apabila belum ada, maka dianggap absen masuk, tapi kalau sudah ada, maka update data sesuai mode absensi
				$cari_absen = mysqli_query($konek, "select * from absensi where nokartu='$nokartu' and tanggal='$tanggal'");
				//hitung jumlah datanya
				$jumlah_absen = mysqli_num_rows($cari_absen);
				if($jumlah_absen == 0)
				{
					echo "<h1>Selamat Datang <br> $nama</h1>";
					mysqli_query($konek, "insert into absensi(nokartu, tanggal, hari, minggu, jam_masuk)values('$nokartu', '$tanggal', '$hari', '$min', '$jam')");
				}
				else
				{
					if($mode_absen == 1)
					{
						echo "<h1>Maaf! Anda sudah absen masuk hari ini";
					}
					else if($mode_absen == 2)
					{
						echo "<h1>Selamat Jalan <br> $nama</h1>";
						mysqli_query($konek, "update absensi set jam_pulang='$jam' where nokartu='$nokartu' and tanggal='$tanggal'");
					}
				}
			}
		}
		else
		{
			echo "<h1>Maaf! Ini hari libur</h1>";
		}
		//kosongkan tabel tmprfid
		mysqli_query($konek, "delete from tmprfid");
	} ?>
	<h3>Silahkan Tempelkan Kartu RFID Anda</h3>
</div>