<?php 
    error_reporting(0);
    include "koneksi.php";
    $menu = "datakaryawan";
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "header.php"; ?>
	<title>Absensi RFID</title>
    <?php include "jsScript.php"; ?>
    <!-- pembacaan no kartu otomatis -->
    <script type="text/javascript">
        $(document).ready(function(){
            setInterval(function(){
                $("#norfid").load('nokartu.php')
            }, 0);  //pembacaan file nokartu.php, tiap 1 detik = 1000
        });
    </script>
</head>
<body>
    <?php
        //jika tombol simpan diklik
        if(isset($_POST['btnSimpan']))
        {
            //baca isi inputan form
            $nokartu = $_POST['nokartu'];
            $nama    = $_POST['nama'];
            $jabatan  = $_POST['jabatan'];

            //simpan ke tabel karyawan
            $simpan = mysqli_query($konek, "insert into karyawan(nokartu, nama, jabatan) values('$nokartu', '$nama', '$jabatan')");

            //jika berhasil tersimpan, tampilkan pesan Tersimpan,
            //kembali ke data karyawan
            if($simpan)
            {
                echo "
                    <script>
                        pesan('Sukses', 'Data berhasil tersimpan', 'success', 'datakaryawan.php');
                    </script>
                ";
            }
            else
            {
                echo "
                    <script>
                        pesan('Error', 'Data gagal tersimpan', 'error', 'datakaryawan.php');
                    </script>
                ";
            }

        }

        //kosongkan tabel tmprfid
        mysqli_query($konek, "delete from tmprfid");
    ?>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div style="display: flex; justify-content: space-between;">
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
						<a href="admin.php"> <button class="btn btn-primary" style="color: white; margin-right: 1px">SMKN7BE</button></a>
						<a href="admin.php"> <button class="btn btn-default" style="margin-right: 1px">Home</button></a>
						</div>
					</li>
				</ul>
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
							<a href="logout.php"> <button class="btn btn-default" style="margin-right: 1px">Logout</button></a>
						</div>
					</li>
				</ul>				
			</div>
		</div>
	</nav>

	<!-- isi -->
	<div class="container-fluid" style="padding-top: 2%">
		  <div class="row" style="margin-left: 10px">
		    <div class="col-6 col-sm-3">
		    	<?php include "menu.php"; ?>
		    </div> 
		    <div class="col-6 col-sm-9" style="text-align: left;">
		    	<!--isi -->
                <div class="container-fluid">
                    <h3>Tambah Data Karyawan</h3>
                            <!-- form input -->
                    <form method="POST">
                        <div id="norfid"></div>

                        <div class="form-group">
                            <label>Nama Karyawan</label>
                            <input type="text" name="nama" id="nama" placeholder="nama karyawan" class="form-control" style="width: 400px">
                        </div>
                        <div class="form-group">
                            <label>Jabatan</label>
                            <input type="text" name="jabatan" id="jabatan" placeholder="jabatan" class="form-control" style="width: 400px">
                        </div>

                        <button class="btn btn-primary" name="btnSimpan" id="btnSimpan">Simpan</button>
                    </form>

                </div>
		    </div>
		  </div>
	</div>
</body>
</html>