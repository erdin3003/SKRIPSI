<?php error_reporting(0); ?>
<table class="table table-bordered" style="font-size: 14px">
    <thead>
        <tr style="background-color: grey; color: white;">
            <th style="width: 10px; text-align: center">No.</th>
            <th style="text-align: center">Nama</th>
            <th style="text-align: center">Jabatan</th>
            <th style="text-align: center; width: 10px">Senin Masuk</th>
            <th style="text-align: center; width: 10px">Senin Pulang</th>
            <th style="text-align: center; width: 10px">Selasa Masuk</th>
            <th style="text-align: center; width: 10px">Selasa Pulang</th>
            <th style="text-align: center; width: 10px">Rabu Masuk</th>
            <th style="text-align: center; width: 10px">Rabu Pulang</th>
            <th style="text-align: center; width: 10px">Kamis Masuk</th>
            <th style="text-align: center; width: 10px">Kamis Pulang</th>
            <th style="text-align: center; width: 10px">Jumat Masuk</th>
            <th style="text-align: center; width: 10px">Jumat Pulang</th>
        </tr>
    </thead>
    <tbody>
        <?php
            //koneksi ke database
            include "koneksi.php";
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $minggu = $_GET['minggu'];
            $nama = $_GET['nama'];
            //baca data karyawan
            if($nama != "")
                $sql = mysqli_query($konek, "select * from karyawan where nama LIKE '%$nama%' order by id asc");
            else
                $sql = mysqli_query($konek, "select * from karyawan order by id asc");

            $no = 0;
            mysqli_query($konek, "DELETE FROM tmprekap");
            while($data = mysqli_fetch_array($sql))
            {
                $no++;
                $nokartu = $data['nokartu'];
                $nama = $data['nama'];
                $jabatan = $data['jabatan'];
                //baca data absensi
                $sql2 = mysqli_query($konek, "select * from absensi where month(tanggal)='$bulan' and year(tanggal)='$tahun' and minggu='$minggu' and nokartu='$nokartu' order by id asc");
                $senin_masuk='-'; $senin_pulang='-';
                $selasa_masuk='-'; $selasa_pulang='-';
                $rabu_masuk='-'; $rabu_pulang='-';
                $kamis_masuk='-'; $kamis_pulang='-';
                $jumat_masuk='-'; $jumat_pulang='-';
                while($data2 = mysqli_fetch_array($sql2))
                {
                    $hari = $data2['hari'];
                    if($hari=="Senin")
                    {
                        $senin_masuk = $data2['jam_masuk'];
                        $senin_pulang = $data2['jam_pulang'];
                    }
                    else if($hari=="Selasa")
                    {
                        $selasa_masuk = $data2['jam_masuk'];
                        $selasa_pulang = $data2['jam_pulang'];
                    }
                    else if($hari=="Rabu")
                    {
                        $rabu_masuk = $data2['jam_masuk'];
                        $rabu_pulang = $data2['jam_pulang'];
                    }
                    else if($hari=="Kamis")
                    {
                        $kamis_masuk = $data2['jam_masuk'];
                        $kamis_pulang = $data2['jam_pulang'];
                    }
                    else if($hari=="Jumat")
                    {
                        $jumat_masuk = $data2['jam_masuk'];
                        $jumat_pulang = $data2['jam_pulang'];
                    }
                }
        ?>

        <tr>
            <td style="text-align: center"> <?php echo $no; ?> </td>
            <td style="text-align: center"> <?php echo $nama; ?> </td>
            <td style="text-align: center"> <?php echo $jabatan; ?> </td>
            <td style="text-align: center"> <?php echo $senin_masuk; ?> </td>
            <td style="text-align: center"> <?php echo $senin_pulang; ?> </td>
            <td style="text-align: center"> <?php echo $selasa_masuk; ?> </td>
            <td style="text-align: center"> <?php echo $selasa_pulang; ?> </td>
            <td style="text-align: center"> <?php echo $rabu_masuk; ?> </td>
            <td style="text-align: center"> <?php echo $rabu_pulang; ?> </td>
            <td style="text-align: center"> <?php echo $kamis_masuk; ?> </td>
            <td style="text-align: center"> <?php echo $kamis_pulang; ?> </td>
            <td style="text-align: center"> <?php echo $jumat_masuk; ?> </td>
            <td style="text-align: center"> <?php echo $jumat_pulang; ?> </td>
        </tr>
        <?php 
            mysqli_query($konek, "ALTER TABLE tmprekap AUTO_INCREMENT=1");
            mysqli_query($konek, "INSERT INTO tmprekap(nama, jabatan, senin_masuk, senin_pulang, selasa_masuk, selasa_pulang, rabu_masuk, rabu_pulang, kamis_masuk, kamis_pulang, jumat_masuk, jumat_pulang)VALUES('$nama', '$jabatan', '$senin_masuk', '$senin_pulang', '$selasa_masuk', '$selasa_pulang', '$rabu_masuk', '$rabu_pulang', '$kamis_masuk', '$kamis_pulang', '$jumat_masuk', '$jumat_pulang')");
        } ?>
    </tbody>
</table>