<?php
    error_reporting();
    $menu="datakaryawan";
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "header.php"; ?>
	<title>Absensi RFID</title>
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div style="display: flex; justify-content: space-between;">
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
						<a href="admin.php"> <button class="btn btn-primary" style="color: white; margin-right: 1px">SMKN7BE</button></a>
						<a href="admin.php"> <button class="btn btn-default" style="margin-right: 1px">Home</button></a>
						</div>
					</li>
				</ul>
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
							<a href="logout.php"> <button class="btn btn-default" style="margin-right: 1px">Logout</button></a>
						</div>
					</li>
				</ul>				
			</div>
		</div>
	</nav>

	<!-- isi -->
	<div class="container-fluid" style="padding-top: 2%">
		  <div class="row" style="margin-left: 10px">
		    <div class="col-6 col-sm-3">
		    	<?php include "menu.php"; ?>
		    </div> 
		    <div class="col-6 col-sm-9" style="text-align: center;">
		    	<!--isi -->
                <div class="container-fluid">
                    <h3>Data Karyawan</h3>
                    <table class="table table-bordered">
                        <thead>
                            <tr style="background-color: grey; color: white;">
                                <th style="width: 10px; text-align: center">No.</th>
                                <th style="width: 200px; text-align: center">No.Kartu</th>
                                <th style="width: 400px; text-align: center">Nama</th>
                                <th style="text-align: center">Jabatan</th>
                                <th style="width: 100px; text-align: center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                                //koneksi ke database
                                include "koneksi.php";

                                //baca data karyawan
                                $sql = mysqli_query($konek, "select * from karyawan");
                                $no = 0;
                                while($data = mysqli_fetch_array($sql))
                                {
                                    $no++;
                            ?>

                            <tr>
                                <td> <?php echo $no; ?> </td>
                                <td> <?php echo $data['nokartu']; ?> </td>
                                <td> <?php echo $data['nama']; ?> </td>
                                <td> <?php echo $data['jabatan']; ?> </td>
                                <td>
                                    <a href="edit.php?id=<?php echo $data['id']; ?>"> Edit</a> | <a href="hapus.php?id=<?php echo $data['id']; ?>"> Hapus</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>

                    <!-- tombol tambah data karyawan -->
                    <div style="text-align: left">
                    <a href="tambah.php"> <button class="btn btn-primary">Tambah Data Karyawan</button> </a>
                    </div>
                </div>
		    </div>
		  </div>
	</div>
</body>
</html>