<!DOCTYPE html>
<html>
<head>
	<?php include "header.php"; ?>
	<title>Absensi RFID</title>

	<!-- scanning membaca kartu RFID -->
	<script type="text/javascript">
		$(document).ready(function() {
			setInterval(function(){
				$("#cekkartu").load('bacakartu.php')
			}, 2000);
		});	
	</script>

</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<ul class="nav navbar-nav">
				<li>
					<div style="display: flex; margin-top: 5px">
					<a href="index.php"> <button class="btn btn-primary" style="color: white; margin-right: 1px">Absensi </button></a>
					<a href="login.php"> <button class="btn btn-default" style="margin-right: 1px">Login </button></a>
					</div>
				</li>
			</ul>
		</div>
	</nav>

	<!-- isi -->
	<div class="container-fluid" style="padding-top: 5%; text-align: center">
		<h1>
			<b>SELAMAT DATANG</b> <br>
			<span style="font-size: 24px">APLIKASI ABSENSI RFID SMK NEGERI 7 BALEENDAH</span><br>
			<div id="cekkartu"></div>
		</h1>
	</div>
</body>
</html>