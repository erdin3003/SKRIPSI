<?php 
    error_reporting(0);
    require_once "phpexcel/Classes/PHPExcel.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Export Absensi</title>

	<style type="text/css">
	body{
		font-family: sans-serif;
	}
	table{
		margin: 20px auto;
		border-collapse: collapse;
	}
	table th,
	table td{
		border: 1px solid #3c3c3c;
		padding: 3px 8px;

	}
	a{
		background: blue;
		color: #fff;
		padding: 8px 10px;
		text-decoration: none;
		border-radius: 2px;
	}
	</style>
</head>
<body>
	<?php
	header("Content-type: application/vnd-ms-excel");
	header("Content-Disposition: attachment; filename=Export.xls");
	?>

	<center>
		<h1>Rekap Absensi</h1>
	</center>
	<table border="1">
	    <thead>
	        <tr>
	            <th style="text-align: center">No.</th>
	            <th style="text-align: center">Nama</th>
	            <th style="text-align: center">Jabatan</th>
	            <th style="text-align: center;">Senin Masuk</th>
	            <th style="text-align: center;">Senin Pulang</th>
	            <th style="text-align: center;">Selasa Masuk</th>
	            <th style="text-align: center;">Selasa Pulang</th>
	            <th style="text-align: center;">Rabu Masuk</th>
	            <th style="text-align: center;">Rabu Pulang</th>
	            <th style="text-align: center;">Kamis Masuk</th>
	            <th style="text-align: center;">Kamis Pulang</th>
	            <th style="text-align: center;">Jumat Masuk</th>
	            <th style="text-align: center;">Jumat Pulang</th>
	        </tr>
	    </thead>
	    <tbody>
	        <?php
	            //koneksi ke database
	            include "koneksi.php";
	            
	            
	            $sql = mysqli_query($konek, "select * from tmprekap order by id asc");

	            $no = 0;
	            while($data = mysqli_fetch_array($sql))
	            {
	                $no++;
	                $nama = $data['nama'];
	                $jabatan = $data['jabatan'];
	                $senin_masuk = $data['senin_masuk'];
	                if($senin_masuk=="00:00:00") $senin_masuk='-';
	                $senin_pulang = $data['senin_pulang'];
	                if($senin_pulang=="00:00:00") $senin_pulang='-';
	                $selasa_masuk = $data['selasa_masuk'];
	                if($selasa_masuk=="00:00:00") $selasa_masuk='-';
	                $selasa_pulang = $data['selasa_pulang'];
	                if($selasa_pulang=="00:00:00") $selasa_pulang='-';
	                $rabu_masuk = $data['rabu_masuk'];
	                if($rabu_masuk=="00:00:00") $rabu_masuk='-';
	                $rabu_pulang = $data['rabu_pulang'];
	                if($rabu_pulang=="00:00:00") $rabu_pulang='-';
	                $kamis_masuk = $data['kamis_masuk'];
	                if($kamis_masuk=="00:00:00") $kamis_masuk='-';
	                $kamis_pulang = $data['kamis_pulang'];
	                if($kamis_pulang=="00:00:00") $kamis_pulang='-';
	                $jumat_masuk = $data['jumat_masuk'];
	                if($jumat_masuk=="00:00:00") $jumat_masuk='-';
	                $jumat_pulang = $data['jumat_pulang'];
	                if($jumat_pulang=="00:00:00") $jumat_pulang='-';
	        ?>
	        <tr>
	            <td style="text-align: center"> <?php echo $no; ?> </td>
	            <td style="text-align: center"> <?php echo $nama; ?> </td>
	            <td style="text-align: center"> <?php echo $jabatan; ?> </td>
	            <td style="text-align: center"> <?php echo $senin_masuk; ?> </td>
	            <td style="text-align: center"> <?php echo $senin_pulang; ?> </td>
	            <td style="text-align: center"> <?php echo $selasa_masuk; ?> </td>
	            <td style="text-align: center"> <?php echo $selasa_pulang; ?> </td>
	            <td style="text-align: center"> <?php echo $rabu_masuk; ?> </td>
	            <td style="text-align: center"> <?php echo $rabu_pulang; ?> </td>
	            <td style="text-align: center"> <?php echo $kamis_masuk; ?> </td>
	            <td style="text-align: center"> <?php echo $kamis_pulang; ?> </td>
	            <td style="text-align: center"> <?php echo $jumat_masuk; ?> </td>
	            <td style="text-align: center"> <?php echo $jumat_pulang; ?> </td>
	        </tr>
	        <?php } ?>
	    </tbody>
	</table>
</body>
</html>