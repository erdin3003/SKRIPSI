    <script src="js/sweetalert2.all.min.js"></script>

    <script type="text/javascript">
      function pesan(caption, isi, simbol,tujuan) {
        Swal.fire({ title: caption,  text: isi,  icon: simbol, allowOutsideClick: false }).then(function() {
            window.location = tujuan;
        });
      }

      function pesanerr(caption, isi, simbol, tujuan) {
        Swal.fire({ title: caption,  text: isi,  icon: simbol, allowOutsideClick: false }).then(function() {
            window.location = tujuan;
        });
      }

      function pesankunci() {
        Swal.fire(
          'Sukses',
          'Jawaban telah dikunci',
          'success'
        )
      }
    </script>