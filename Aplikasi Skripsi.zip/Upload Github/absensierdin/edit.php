<?php 
    error_reporting();
    include "koneksi.php";
    $menu = "datakaryawan";
?>

<!DOCTYPE html>
<html>
<head>
	<?php include "header.php"; ?>
	<title>Absensi RFID</title>
    <?php include "jsScript.php"; ?>
</head>
<body>
    <?php 
        error_reporting();
        include "koneksi.php";

        $id = $_GET['id'];
        //jika tombol simpan diklik
        if(isset($_POST['btnSimpan']))
        {
            //baca isi inputan form
            $nokartu = $_POST['nokartu'];
            $nama    = $_POST['nama'];
            $jabatan = $_POST['jabatan'];

            //simpan ke tabel karyawan
            $simpan = mysqli_query($konek, "update karyawan set nama='$nama', jabatan='$jabatan' where id='$id'");

            //jika berhasil tersimpan, tampilkan pesan Tersimpan,
            //kembali ke data karyawan
            if($simpan)
            {
                echo "
                    <script>
                        pesan('Sukses', 'Data berhasil tersimpan', 'success', 'datakaryawan.php');
                    </script>
                ";
            }
            else
            {
                echo "
                    <script>
                        pesan('Error', 'Data gagal tersimpan', 'error', 'datakaryawan.php');
                    </script>
                ";
            }

        }

        $sql = mysqli_query($konek, "select * from karyawan where id='$id'");
        $data = mysqli_fetch_array($sql);
        $nokartu = $data['nokartu'];
        $nama = $data['nama'];
        $jabatan = $data['jabatan'];

        //kosongkan tabel tmprfid
        mysqli_query($konek, "delete from tmprfid");
    ?>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<div style="display: flex; justify-content: space-between;">
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
						<a href="admin.php"> <button class="btn btn-primary" style="color: white; margin-right: 1px">SMKN7BE</button></a>
						<a href="admin.php"> <button class="btn btn-default" style="margin-right: 1px">Home</button></a>
						</div>
					</li>
				</ul>
				<ul class="nav navbar-nav">
					<li>
						<div style="display: flex; margin-top: 5px">
							<a href="logout.php"> <button class="btn btn-default" style="margin-right: 1px">Logout</button></a>
						</div>
					</li>
				</ul>				
			</div>
		</div>
	</nav>

	<!-- isi -->
	<div class="container-fluid" style="padding-top: 2%">
		  <div class="row" style="margin-left: 10px">
		    <div class="col-6 col-sm-3">
		    	<?php include "menu.php"; ?>
		    </div> 
		    <div class="col-6 col-sm-9" style="text-align: left;">
		    	<!--isi -->
                <div class="container-fluid">
                    <h3>Edit Data Karyawan</h3>
                            <!-- form input -->
                    <form method="POST">
                        <div class="form-group">
                            <label>No.Kartu</label>
                            <input type="text" name="nokartu"id="nokartu" placeholder="tempelkan kartu rfid Anda" class="form-control" style="width: 200px" value="<?php echo $nokartu; ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>Nama Karyawan</label>
                            <input type="text" name="nama" id="nama" placeholder="nama karyawan" value="<?php echo $nama; ?>" class="form-control" style="width: 400px">
                        </div>
                        <div class="form-group">
                            <label>Jabatan</label>
                            <input type="text" name="jabatan" id="jabatan" placeholder="jabatan" value="<?php echo $jabatan; ?>" class="form-control" style="width: 400px">
                        </div>

                        <button class="btn btn-primary" name="btnSimpan" id="btnSimpan">Simpan</button>
                    </form>

                </div>
		    </div>
		  </div>
	</div>
</body>
</html>